var cart = {
    // (A) PROPERTIES
    hPdt : null,      //  products list
    hItems : null,    // current cart
    items : {},       // items in cart
    iURL : "images/", // image url folder
  
    // (B) Local storage cart
    // (B1) Save current cart on local cart
    save : () => {
      localStorage.setItem("cart", JSON.stringify(cart.items));
    },
  
    // (B2) code that loads cart to ocalstoage cart
    load : () => {
      cart.items = localStorage.getItem("cart");
      if (cart.items == null) { cart.items = {}; }
      else { cart.items = JSON.parse(cart.items); }
    },
  
    // (B3) Code that empties the cart
    nuke : () => { if (confirm("Are you sure you want to empty the cart?")) {
      cart.items = {};
      localStorage.removeItem("cart");
      cart.list();
    }},
  
    
    init : () => {
      // (C1) Code that gets html elements.
      cart.hPdt = document.getElementById("cart-products");
      cart.hItems = document.getElementById("cart-items");
  
      // (C2) Draw product list
      cart.hPdt.innerHTML = "";
      let template = document.getElementById("template-product").content,
          p, item, part;
      for (let id in products) {
        p = products[id];
        item = template.cloneNode(true);
        item.querySelector(".p-img").src = cart.iURL + p.img;
        item.querySelector(".p-name").textContent = p.name;
        item.querySelector(".p-desc").textContent = p.desc;
        item.querySelector(".p-price").textContent = "$" + p.price.toFixed(2);
        item.querySelector(".p-add").onclick = () => { cart.add(id); };
        cart.hPdt.appendChild(item);
      }
  
      // (C3) Code that loads cart from previous 
      cart.load();
  
      // (C4) Code that lists current cart items
      cart.list();
    },
  
    // (D) Code hat lists items in html
    list : () => {
      // (D1) RESET
      cart.hItems.innerHTML = "";
      let item, part, pdt, empty = true;
      for (let key in cart.items) {
        if (cart.items.hasOwnProperty(key)) { empty = false; break; }
      }
  
      // (D2) Code that prints out cart is empty
      if (empty) {
        item = document.createElement("div");
        item.innerHTML = "Cart is empty";
        cart.hItems.appendChild(item);
      }
  
      // (D3) Code that lists cart is empty
      else {
        let template = document.getElementById("template-cart").content,
            p, total = 0, subtotal = 0;
        for (let id in cart.items) {
          // (D3-1) PRODUCT ITEM
          p = products[id];
          item = template.cloneNode(true);
          item.querySelector(".c-del").onclick = () => { cart.remove(id); };
          item.querySelector(".c-name").textContent = p.name;
          item.querySelector(".c-qty").value = cart.items[id];
          item.querySelector(".c-qty").onchange = function () { cart.change(id, this.value); };
          cart.hItems.appendChild(item);
  
          // (D3-2) Subtotal code
          subtotal = cart.items[id] * p.price;
          total += subtotal;
        }
  
        // (D3-3) Total amount code
        item = document.createElement("div");
        item.className = "c-total";
        item.id = "c-total";
        item.innerHTML ="TOTAL: $" + total;
        cart.hItems.appendChild(item);
  
        // (D3-4) Code to empty and check out
        item = document.getElementById("template-cart-checkout").content.cloneNode(true);
        cart.hItems.appendChild(item);
      }
    },
  
    // (E) Add item to cart
    add : (id) => {
      if (cart.items[id] == undefined) { cart.items[id] = 1; }
      else { cart.items[id]++; }
      cart.save(); cart.list();
    },
  
    // (F) Change quanitity
    change : (pid, qty) => {
      // (F1) REMOVE ITEM
      if (qty <= 0) {
        delete cart.items[pid];
        cart.save(); cart.list();
      }
  
      // (F2) code that updates total only
      else {
        cart.items[pid] = qty;
        var total = 0;
        for (let id in cart.items) {
          total += cart.items[id] * products[id].price;
          document.getElementById("c-total").innerHTML ="TOTAL: $" + total;
        }
      }
    },
  
    // (G) Code that removed cart from item 
    remove : (id) => {
      delete cart.items[id];
      cart.save();
      cart.list();
    },
  
    checkout : () => {
  
      alert("Your Order is confirmed!");
  
    
    }
  };
  window.addEventListener("DOMContentLoaded", cart.init);
  