var products = {
    123: {
      name : "Deep Dark",
      desc : "Take your coffee game up a notch this summer with our iced caramel macchiato – it's made with espresso, milk, vanilla syrup and caramel sauce",
      img : "coffee1-pdt-a.jpg",
      price : 6.20
    },
    124: {
      name : "Ellis Island",
      desc : "Cool off with a refreshing iced latte. This simple drink only needs a handful of ingredients and is perfect for a hot weather caffeine kick",
      img : "coffee2-pdt-b.jpg",
      price : 4.30
    },
    125: {
      name : "New York Express",
      desc : "Combine the richness of chocolate milk with a hit of espresso and a whipped cream topping to make a moreish iced mocha – it's like a dessert in a glass.",
      img : "coffee3-pdt-d.jpg",
      price : 6.75
    },
    126: {
      name : "Coffee Frape",
      desc : "Wow your party guests with this easy, light dessert and after-dinner coffee all rolled into one. It's a lovely end to any meal and a cooling treat in summer. ",
      img : "coffee4-pdt-c.jpg",
      price : 3.30
    }, 
    127: {
      name : "Red Eye",
      desc : "Ready to wake up? Take your coffee to the net level. Two shots of espresso—a real eye-opener!",
      img : "coffee5-pdt-e.jpg",
      price : 5.50
    },
    128: {
      name : "Five Oclock Break",
      desc : "This delicious, fragrant, and refreshing cold-brew drink is made with fig and lavender syrup! It’s so flavorful and perfect for hot summer days!",
      img : "coffee6-pdt-f.jpg",
      price : 7.20
    }
  };
  